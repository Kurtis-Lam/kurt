#!/usr/bin/env python3
"""kurtis - a terminal coding assistant powered by Qwythos (via Ollama).

Run `kurtis` in any project folder. Kurtis can read your files and propose
edits / new files / shell commands. Nothing is changed without your OK.
"""
import difflib
import json
import os
import re
import shutil
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt
from rich.syntax import Syntax

__version__ = "0.1.0"

MODEL = os.environ.get(
    "KURTIS_MODEL", "hf.co/empero-ai/Qwythos-9B-Claude-Mythos-5-1M-GGUF:Q4_K_M"
)
_host = os.environ.get("OLLAMA_HOST", "http://127.0.0.1:11434")
if not _host.startswith("http"):
    _host = "http://" + _host
HOST = _host.replace("0.0.0.0", "127.0.0.1").rstrip("/")
CTX = int(os.environ.get("KURTIS_CTX", "16384"))  # context window sent to Ollama
MAX_ROUNDS = 6  # max automatic read/run follow-ups per user message
IGNORE_DIRS = {
    ".git", "node_modules", "__pycache__", ".venv", "venv", "dist", "build",
    ".idea", ".vscode", "target", ".next", ".cache", ".pytest_cache",
}

console = Console(highlight=False)
AUTO = False  # "accept all edits" for this session
UNDO = []  # stack of (path, old_text_or_None, crlf)

SYSTEM = """You are Kurtis, an expert coding assistant running inside the user's terminal.
Project directory: {cwd}

You can act on the project by emitting ACTION BLOCKS. The user is asked to confirm
every change, and results are sent back to you. Formats (exactly):

Read a file:
@@@ READ relative/path.py
@@@ END

Edit an existing file (SEARCH must match the file EXACTLY, including whitespace;
keep it small but unique; several SEARCH/REPLACE pairs are allowed):
@@@ EDIT relative/path.py
<<<<<<< SEARCH
old code
=======
new code
>>>>>>> REPLACE
@@@ END

Create a new file or fully overwrite one:
@@@ WRITE relative/path.py
full file contents
@@@ END

Run a shell command (user confirms first):
@@@ RUN python -m pytest -q
@@@ END

Rules:
- READ a file before editing it. Never guess file contents.
- Use paths relative to the project directory.
- Make minimal, focused edits. Prefer EDIT over WRITE for existing files.
- Briefly explain what you are doing, then emit the blocks. Do not wrap blocks in code fences.
- Do not claim a change is applied until the tool result says so.
- If a tool result reports an error, fix your block and try again.
"""

BLOCK_RE = re.compile(r"@@@ (EDIT|WRITE|READ|RUN) ?([^\n]*)\n(.*?)\n?@@@ END", re.S)
PAIR_RE = re.compile(
    r"<<<<<<< SEARCH\n(.*?)\n=======\n(.*?)\n?>>>>>>> REPLACE", re.S
)


# ----------------------------------------------------------------- Ollama ---
def http_json(path, payload=None, timeout=5):
    data = json.dumps(payload).encode() if payload is not None else None
    req = urllib.request.Request(
        HOST + path, data=data, headers={"Content-Type": "application/json"}
    )
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode() or "{}")


def ollama_up():
    try:
        http_json("/api/tags", timeout=2)
        return True
    except Exception:
        return False


def ensure_ollama():
    if ollama_up():
        return True
    exe = shutil.which("ollama")
    if not exe:
        console.print(
            "[red]Ollama isn't installed or isn't on PATH.[/] Get it at https://ollama.com/download"
        )
        return False
    with console.status("Starting Ollama..."):
        kwargs = {}
        if os.name == "nt":
            kwargs["creationflags"] = 0x08000000  # CREATE_NO_WINDOW
        subprocess.Popen(
            [exe, "serve"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, **kwargs
        )
        for _ in range(40):
            if ollama_up():
                return True
            time.sleep(0.5)
    console.print("[red]Could not start Ollama.[/]")
    return False


def model_installed():
    try:
        names = [m.get("name", "") for m in http_json("/api/tags").get("models", [])]
    except Exception:
        return False
    base = MODEL if ":" in MODEL.split("/")[-1] else MODEL + ":latest"
    return any(n == base or n == MODEL for n in names)


def ensure_model():
    if model_installed():
        return True
    console.print(f"[yellow]Model not found locally:[/] {MODEL}")
    if Prompt.ask("Download it now?", choices=["y", "n"], default="y") != "y":
        return False
    return subprocess.run(["ollama", "pull", MODEL]).returncode == 0


def warm_model():
    with console.status("Loading Qwythos into memory..."):
        try:
            http_json(
                "/api/generate",
                {"model": MODEL, "keep_alive": "30m", "options": {"num_ctx": CTX}},
                timeout=600,
            )
        except Exception as e:
            console.print(f"[yellow]Warm-up skipped:[/] {e}")


def stream_chat(messages):
    payload = {
        "model": MODEL,
        "messages": messages,
        "stream": True,
        "keep_alive": "30m",
        "options": {"num_ctx": CTX, "temperature": 0.2},
    }
    req = urllib.request.Request(
        HOST + "/api/chat",
        data=json.dumps(payload).encode(),
        headers={"Content-Type": "application/json"},
    )
    with urllib.request.urlopen(req, timeout=900) as r:
        for line in r:
            if not line.strip():
                continue
            d = json.loads(line)
            if "error" in d:
                raise RuntimeError(d["error"])
            m = d.get("message", {})
            if m.get("thinking"):
                yield "thinking", m["thinking"]
            if m.get("content"):
                yield "content", m["content"]
            if d.get("done"):
                break


# ------------------------------------------------------------- File utils ---
def safe_path(p):
    """Resolve p relative to cwd; return None if it escapes the project dir."""
    try:
        full = (Path.cwd() / p.strip().strip("'\"")).resolve()
        full.relative_to(Path.cwd().resolve())
        return full
    except Exception:
        return None


def read_file(path):
    with open(path, "r", encoding="utf-8", errors="replace", newline="") as f:
        raw = f.read()
    crlf = "\r\n" in raw
    return raw.replace("\r\n", "\n"), crlf


def write_file(path, text, crlf=False):
    path.parent.mkdir(parents=True, exist_ok=True)
    if crlf:
        text = text.replace("\n", "\r\n")
    with open(path, "w", encoding="utf-8", newline="") as f:
        f.write(text)


def project_tree(limit=150):
    root = Path.cwd()
    out = []
    for dirpath, dirs, files in os.walk(root):
        dirs[:] = sorted(d for d in dirs if d not in IGNORE_DIRS and not d.startswith("."))
        for fn in sorted(files):
            if fn.startswith(".") and fn not in (".env.example", ".gitignore"):
                continue
            out.append(str(Path(dirpath, fn).relative_to(root)).replace("\\", "/"))
            if len(out) >= limit:
                out.append("... (truncated)")
                return "\n".join(out)
    return "\n".join(out) or "(empty directory)"


def show_diff(old, new, name):
    diff = "".join(
        difflib.unified_diff(
            old.splitlines(True), new.splitlines(True), f"a/{name}", f"b/{name}", n=3
        )
    )
    lines = diff.splitlines()
    if len(lines) > 120:
        diff = "\n".join(lines[:120]) + f"\n... ({len(lines) - 120} more lines)"
    console.print(Syntax(diff or "(no changes)", "diff", theme="ansi_dark"))


def show_new_file(name, text):
    lines = text.splitlines()
    shown = "\n".join(lines[:80]) + (f"\n... ({len(lines) - 80} more lines)" if len(lines) > 80 else "")
    try:
        lexer = Syntax.guess_lexer(name, shown)
    except Exception:
        lexer = "text"
    console.print(Syntax(shown, lexer, theme="ansi_dark", line_numbers=True))


def confirm(question):
    global AUTO
    if AUTO:
        return True
    a = Prompt.ask(question, choices=["y", "n", "a"], default="y", console=console)
    if a == "a":
        AUTO = True
        console.print("[dim]Auto-accepting edits for this session (/auto to toggle).[/]")
        return True
    return a == "y"


# ---------------------------------------------------------------- Actions ---
def do_read(arg):
    p = safe_path(arg)
    if not p or not p.is_file():
        return f"READ {arg}: ERROR file not found (or outside project)."
    text, _ = read_file(p)
    console.print(f"[dim]📖 read {arg} ({len(text)} chars)[/]")
    if len(text) > 30000:
        text = text[:30000] + "\n... [truncated]"
    return f"READ {arg}:\n{text}"


def do_edit(arg, body):
    p = safe_path(arg)
    if not p or not p.is_file():
        return f"EDIT {arg}: ERROR file not found (or outside project). Use WRITE to create files."
    pairs = PAIR_RE.findall(body)
    if not pairs:
        return f"EDIT {arg}: ERROR no valid SEARCH/REPLACE pairs found."
    old, crlf = read_file(p)
    new = old
    for i, (s, r) in enumerate(pairs, 1):
        n = new.count(s)
        if n == 0:
            return f"EDIT {arg}: ERROR SEARCH #{i} not found. It must match the file exactly. Re-READ the file."
        if n > 1:
            return f"EDIT {arg}: ERROR SEARCH #{i} matches {n} places. Include more context to make it unique."
        new = new.replace(s, r, 1)
    console.print(Panel(f"[bold]Edit[/] {arg}", border_style="yellow", expand=False))
    show_diff(old, new, arg)
    if not confirm("Apply this edit? (y=yes, n=no, a=yes to all)"):
        return f"EDIT {arg}: REJECTED by user."
    UNDO.append((p, old, crlf))
    write_file(p, new, crlf)
    console.print(f"[green]✔ edited {arg}[/]")
    return f"EDIT {arg}: applied."


def do_write(arg, body):
    p = safe_path(arg)
    if not p:
        return f"WRITE {arg}: ERROR path outside project."
    exists = p.is_file()
    old, crlf = read_file(p) if exists else ("", False)
    new = body if body.endswith("\n") else body + "\n"
    verb = "Overwrite" if exists else "Create"
    console.print(Panel(f"[bold]{verb}[/] {arg}", border_style="yellow", expand=False))
    if exists:
        show_diff(old, new, arg)
    else:
        show_new_file(arg, new)
    if not confirm(f"{verb} this file? (y=yes, n=no, a=yes to all)"):
        return f"WRITE {arg}: REJECTED by user."
    UNDO.append((p, old if exists else None, crlf))
    write_file(p, new, crlf)
    console.print(f"[green]✔ wrote {arg}[/]")
    return f"WRITE {arg}: applied."


def do_run(cmd):
    cmd = cmd.strip()
    console.print(Panel(f"[bold]Run command[/]\n{cmd}", border_style="red", expand=False))
    if Prompt.ask("Run it?", choices=["y", "n"], default="n", console=console) != "y":
        return f"RUN {cmd}: REJECTED by user."
    try:
        r = subprocess.run(
            cmd, shell=True, capture_output=True, text=True, timeout=180,
            cwd=Path.cwd(), errors="replace",
        )
        out = ((r.stdout or "") + (r.stderr or "")).strip()
        code = r.returncode
    except subprocess.TimeoutExpired:
        out, code = "timed out after 180s", -1
    console.print(out[:3000] or "[dim](no output)[/]", markup=False)
    if len(out) > 4000:
        out = out[:4000] + "\n... [truncated]"
    return f"RUN {cmd}: exit code {code}\n{out}"


def handle_actions(text):
    text = re.sub(r"<think>.*?</think>", "", text, flags=re.S)
    results = []
    for kind, arg, body in BLOCK_RE.findall(text):
        arg = arg.strip()
        if kind == "READ":
            results.append(do_read(arg))
        elif kind == "EDIT":
            r = do_edit(arg, body)
            if "ERROR" in r:
                console.print(f"[red]{r}[/]")
                results.append(r)
        elif kind == "WRITE":
            r = do_write(arg, body)
            if "ERROR" in r:
                console.print(f"[red]{r}[/]")
                results.append(r)
        elif kind == "RUN":
            results.append(do_run(arg or body))
    if not results:
        return ""
    return "[tool results]\n" + "\n\n".join(results)


# ------------------------------------------------------------------- Chat ---
def trim(messages):
    budget = int(CTX * 3)  # ~3 chars per token, leave headroom
    while sum(len(m["content"]) for m in messages) > budget and len(messages) > 3:
        del messages[1]


def attach_mentions(text):
    extra = []
    for m in set(re.findall(r"@([\w./\\-]+)", text)):
        p = safe_path(m)
        if p and p.is_file():
            content, _ = read_file(p)
            extra.append(f"\n\n[Attached file {m}]\n{content[:30000]}")
            console.print(f"[dim]📎 attached {m}[/]")
    return text + "".join(extra)


def run_turn(messages):
    for _ in range(MAX_ROUNDS):
        trim(messages)
        full, interrupted = "", False
        console.print()
        try:
            for kind, chunk in stream_chat(messages):
                if kind == "thinking":
                    console.print(chunk, style="dim", end="", markup=False, soft_wrap=True)
                else:
                    full += chunk
                    console.print(chunk, end="", markup=False, soft_wrap=True)
        except KeyboardInterrupt:
            interrupted = True
            console.print("\n[yellow]⏹ interrupted[/]")
        except Exception as e:
            console.print(f"\n[red]Error talking to Ollama:[/] {e}")
            if messages and messages[-1]["role"] == "user":
                messages.pop()
            return
        console.print()
        messages.append({"role": "assistant", "content": full})
        if interrupted:
            return
        feedback = handle_actions(full)
        if not feedback:
            return
        messages.append({"role": "user", "content": feedback})
    console.print("[yellow]Stopped after several automatic steps. Say 'continue' to go on.[/]")


HELP = """[bold]Commands[/]
  /help           show this help
  /files          list project files
  /add <path>     put a file's contents into the conversation (or use @path in a message)
  /auto           toggle auto-accept for file edits (commands always ask)
  /undo           revert the last applied change
  /clear          forget the conversation
  /exit           quit  (Ctrl+C while Kurtis is typing stops generation)"""


def new_messages():
    return [{"role": "system", "content": SYSTEM.replace("{cwd}", str(Path.cwd()))}]


def handle_command(line, messages):
    global AUTO
    cmd, _, arg = line.partition(" ")
    cmd = cmd.lower()
    if cmd in ("/exit", "/quit", "/q"):
        return "exit"
    if cmd == "/help":
        console.print(HELP)
    elif cmd == "/files":
        console.print(project_tree(), markup=False)
    elif cmd == "/clear":
        messages[:] = new_messages()
        console.print("[dim]conversation cleared[/]")
    elif cmd == "/auto":
        AUTO = not AUTO
        console.print(f"auto-accept edits: [bold]{'ON' if AUTO else 'OFF'}[/]")
    elif cmd == "/add":
        p = safe_path(arg)
        if not p or not p.is_file():
            console.print("[red]file not found[/]")
        else:
            text, _ = read_file(p)
            messages.append({"role": "user", "content": f"[File {arg}]\n{text[:30000]}"})
            messages.append({"role": "assistant", "content": f"Got it, I have {arg}."})
            console.print(f"[dim]added {arg}[/]")
    elif cmd == "/undo":
        if not UNDO:
            console.print("[dim]nothing to undo[/]")
        else:
            p, old, crlf = UNDO.pop()
            if old is None:
                p.unlink(missing_ok=True)
            else:
                write_file(p, old, crlf)
            console.print(f"[green]↩ reverted {p.name}[/]")
    else:
        console.print("[red]unknown command[/] — try /help")
    return None


def main():
    if len(sys.argv) > 1 and sys.argv[1] in ("-v", "--version"):
        print(f"kurtis {__version__}")
        return
    if len(sys.argv) > 1 and sys.argv[1] in ("-h", "--help"):
        print(__doc__)
        print("Env: KURTIS_MODEL, KURTIS_CTX, OLLAMA_HOST")
        return
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

    console.print(
        Panel.fit(
            f"[bold magenta]Kurtis[/] v{__version__}  ·  Qwythos via Ollama\n"
            f"[dim]{Path.cwd()}[/]",
            border_style="magenta",
        )
    )
    if not ensure_ollama() or not ensure_model():
        sys.exit(1)
    warm_model()

    messages = new_messages()
    messages.append(
        {"role": "user", "content": f"Files in this project:\n{project_tree()}"}
    )
    messages.append(
        {"role": "assistant", "content": "Understood. I can READ, EDIT, WRITE and RUN as needed. What should we work on?"}
    )
    console.print("[dim]Ask for changes in plain English. /help for commands. Use @file to attach a file.[/]\n")

    while True:
        try:
            line = console.input("[bold cyan]kurtis ❯[/] ").strip()
        except (EOFError, KeyboardInterrupt):
            console.print()
            break
        if not line:
            continue
        if line.startswith("/"):
            if handle_command(line, messages) == "exit":
                break
            continue
        messages.append({"role": "user", "content": attach_mentions(line)})
        run_turn(messages)


if __name__ == "__main__":
    main()
